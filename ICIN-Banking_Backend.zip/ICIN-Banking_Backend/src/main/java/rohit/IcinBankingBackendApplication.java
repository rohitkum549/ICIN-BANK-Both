package rohit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcinBankingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcinBankingBackendApplication.class, args);
	}

}
 